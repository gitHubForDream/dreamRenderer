/*
dream Renderer
author: forDream
*/

#include"Model.h"

Model::Model(string path)
{
	this->LoadModel(path);
}

void Model::LoadModel(string path)
{
	Assimp::Importer importer;
	const aiScene* scene = importer.ReadFile(path, aiProcess_Triangulate | aiProcess_FlipUVs | aiProcess_CalcTangentSpace);
	if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode)
	{
		cout << "load obj error" << endl;
		return;
	}
	this->dir_path = path.substr(0, path.find_last_of('/'));
	this->scene = scene;
	this->LoadScene();
}

void Model::LoadScene()
{
	scene = this->scene;
	aiNode* root_node = scene->mRootNode;
	this->LoadNode(root_node);
}

void Model::LoadNode(aiNode *node)
{
	for (unsigned int i = 0; i < node->mNumMeshes; i++)
	{
		aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
		meshes.push_back(this->LoadMesh(mesh));
	}

	for (unsigned int i = 0; i < node->mNumChildren; i++)
	{
		this->LoadNode(node->mChildren[i]);
	}
}

Mesh Model::LoadMesh(aiMesh *mesh)
{
	vector<Vertex> vertices;
	vector<unsigned int> indices;
	vector<Texture> textures;
	
	for (unsigned int i = 0; i < mesh->mNumVertices; i++)
	{
		Vertex vertex;
		vec3f vector3;

		vector3.x = mesh->mVertices[i].x;
		vector3.y = mesh->mVertices[i].y;
		vector3.z = mesh->mVertices[i].z;
		vertex.position = vector3;

		vector3.x = mesh->mNormals[i].x;
		vector3.y = mesh->mNormals[i].y;
		vector3.z = mesh->mNormals[i].z;
		vertex.normal = vector3;
		
		if (mesh->mTextureCoords[0])
		{
			vec2f vector2;
			vector2.x = mesh->mTextureCoords[0][i].x;
			vector2.y = mesh->mTextureCoords[0][i].y;
			vertex.texcoords = vector2;
		}
		else
		{
			vertex.texcoords = vec2f(0.0f, 0.0f);
		}

		//vector3.x = mesh->mTangents[i].x;
		//vector3.y = mesh->mTangents[i].y;
		//vector3.z = mesh->mTangents[i].z;
		//vertex.tangent = vector3;

		//vector3.x = mesh->mBitangents[i].x;
		//vector3.y = mesh->mBitangents[i].y;
		//vector3.z = mesh->mBitangents[i].z;
		//vertex.bitangent = vector3;

		vertices.push_back(vertex);
	}

	for (unsigned int i = 0; i < mesh->mNumFaces; i++)
	{
		aiFace face = mesh->mFaces[i];
		for (unsigned int j = 0; j < face.mNumIndices; j++)
		{
			indices.push_back(face.mIndices[j]);
		}
	}

	aiMaterial* material = scene->mMaterials[mesh->mMaterialIndex];

	vector<Texture> diffuse_textures = this->LoadMaterialTexture(material, aiTextureType_DIFFUSE, "texture_diffuse");
	textures.insert(textures.end(), diffuse_textures.begin(), diffuse_textures.end());

	vector<Texture> specular_textures = this->LoadMaterialTexture(material, aiTextureType_SPECULAR, "texture_specular");
	textures.insert(textures.end(), specular_textures.begin(), specular_textures.end());

	vector<Texture> reflect_textures = this->LoadMaterialTexture(material, aiTextureType_AMBIENT, "texture_ambient");
	textures.insert(textures.end(), reflect_textures.begin(), reflect_textures.end());

	vector<Texture> normal_textures = this->LoadMaterialTexture(material, aiTextureType_NORMALS, "texture_normal");
	textures.insert(textures.end(), normal_textures.begin(), normal_textures.end());
		
	return Mesh(vertices, indices, textures);
}

vector<Texture> Model::LoadMaterialTexture(aiMaterial *mat, aiTextureType texture_type, string type)
{
	vector<Texture> textures;
	for (int i = 0; i < mat->GetTextureCount(texture_type); i++)
	{
		aiString path;
		mat->GetTexture(texture_type, i, &path);
		bool is_skip = false;
		for (int j = 0; j < this->textures_loaded.size(); j++)
		{
			cout << this->textures_loaded[j].path.data() << endl;
			cout << path.C_Str() << endl;
			if (strcmp(this->textures_loaded[j].path.data(), path.C_Str()) == 0)
			{
				textures.push_back(textures_loaded[j]);
				is_skip = true;
				break;
			}
		}
		if (!is_skip)
		{
			Texture texture;
			texture.type = type;
			texture.path = path.C_Str();
			this->LoadTextureData(string(path.C_Str()), texture);
			textures.push_back(texture);
			textures_loaded.push_back(texture);
		}
	}
	return textures;
}

void Model::LoadTextureData(string file_name, Texture& texture)
{
	string file_path = this->dir_path + '/' + file_name;

	int width, height;
	int channels;
	unsigned char* data = stbi_load(file_path.c_str(), &width, &height, &channels, 0);
	texture.data = data;
	texture.width = width;
	texture.height = height;
	texture.channels = channels;
}
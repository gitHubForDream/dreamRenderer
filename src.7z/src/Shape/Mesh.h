/*
dream Renderer
author: forDream
*/

#pragma once
#include"Core/Geometry.h"
#include"Core/Texture.h"
#include<vector>

using namespace std;

struct Vertex
{
	vec3f position;
	vec3f normal;
	vec3f tangent;
	vec3f bitangent;
	vec2f texcoords;
};

class Mesh
{
public:
	Mesh(vector<Vertex> vertices, vector<unsigned int> indices, vector<Texture> textures);
	
	vector<Vertex> vertices;
	vector<unsigned int> indices;
	vector<Texture> textures;
};
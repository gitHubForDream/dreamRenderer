/*
dream Renderer
author: forDream
*/

#pragma once

#include"Mesh.h"
#include"Core/GameObject.h"
#include"include/assimp/scene.h"
#include"include/assimp/postprocess.h"
#include"include/assimp/Importer.hpp"
#include"include/stb_image.h"

using namespace std;

class Model: public GameObject
{
public:
	Model(string path);

	void LoadModel(string path);
	void LoadScene();
	void LoadNode(aiNode *node);
	Mesh LoadMesh(aiMesh *mesh);
	vector<Texture> LoadMaterialTexture(aiMaterial *mat, aiTextureType texture_type, string type);
	vector<Mesh> meshes;
	vector<Texture> textures_loaded;
	void LoadTextureData(string file_name, Texture& texture);
	const aiScene* scene;
	string dir_path;
};

extern Model model;
/*
dream Renderer
author: forDream
*/

#include"Core/Camera.h"

GameObject::GameObject()
{
	this->scale = vec3f(1.0, 1.0, 1.0);
}

vec3f GameObject::GetPos() const
{
	return this->pos;
}

void GameObject::SetPos(vec3f pos)
{
	this->pos = pos;
}

vec3f GameObject::GetRotation() const
{
	return this->rotate;
}

void GameObject::SetRotation(vec3f rotate)
{
	this->rotate = rotate;
}

vec3f GameObject::GetScale() const
{
	return this->scale;
}

void GameObject::SetScale(vec3f scale)
{
	this->scale = scale;
}
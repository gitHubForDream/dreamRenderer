/*
dream Renderer
author: forDream
*/
#pragma once

const int FRAME_BUFFER_WIDTH = 1024;
const int FRAME_BUFFER_HEIGHT = 768;

class FrameBuffer
{
public:
	FrameBuffer();
	FrameBuffer(int width, int height);
	void ClearFrameBuffer();
	char* GetFrameBuffer();
	void SetFrameBuffer(char* buffer);
	void SetColor(int x, int y, int r, int g, int b);
	bool DepthTest(int x, int y, double depth, bool is_write_depth=true);
	int Height();
	int Width();
private:
	char* color_buffer;
	double* depth_buffer;
	int width;
	int height;
};

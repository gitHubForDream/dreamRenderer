#pragma once
#include<string>

using namespace std;

struct Texture
{
	string type;
	string path;
	int width;
	int height;
	int channels;
	unsigned char* data;
};

/*
dream Renderer
author: forDream
*/
#pragma once

class Shader
{
public:
	void Vertex();
	void Fragment();
};

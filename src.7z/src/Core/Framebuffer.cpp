/*
dream Renderer
author: forDream
*/


#include"Framebuffer.h"
#include<stdlib.h>
#include<cstring>

FrameBuffer::FrameBuffer() {}

FrameBuffer::FrameBuffer(int width_, int height_) :width(width_), height(height_)
{
	int color_buffer_size = this->width * this->height * 4 * sizeof(char);
	this->color_buffer = (char*)malloc(color_buffer_size);
	memset(color_buffer, 0, color_buffer_size);

	int depth_buffer_size = this->width * this->height * sizeof(double);
	this->depth_buffer = (double*)malloc(depth_buffer_size);
	memset(depth_buffer, -10000.0, depth_buffer_size);
}

void FrameBuffer::ClearFrameBuffer()
{
	int color_buffer_size = this->width * this->height * 4 * sizeof(char);
	memset(color_buffer, 100, color_buffer_size);

	int depth_buffer_size = this->width * this->height * sizeof(double);
	memset(depth_buffer, -10000.0, depth_buffer_size);
}

char* FrameBuffer::GetFrameBuffer()
{
	return this->color_buffer;
}

void FrameBuffer::SetFrameBuffer(char* buffer)
{
	this->color_buffer = buffer;
}

void FrameBuffer::SetColor(int x, int y, int r, int g, int b)
{	
	int index = (y * FRAME_BUFFER_WIDTH + x) * 4;
	if(index<0)
	{
		return;
	}
	this->color_buffer[index] = b;
	this->color_buffer[index + 1] = g;
	this->color_buffer[index + 2] = r;
}

bool FrameBuffer::DepthTest(int x, int y, double depth, bool is_write_depth)
{
	int index = (y * FRAME_BUFFER_WIDTH + x);
	if (index<0)
	{
		return false;
	}
	bool depth_test = false;
	if (this->depth_buffer[index] < depth)
	{
		depth_test = true;
	}
	if (depth_test && is_write_depth)
	{
		this->depth_buffer[index] = depth;
	}
	return depth_test;
}

int FrameBuffer::Height()
{
	return this->height;
}

int FrameBuffer::Width()
{
	return this->width;
}
/*
dream Renderer
author: forDream
*/

#include"Core/Shader.h"

void Shader::Vertex()
{

}

void Shader::Fragment()
{

}

/*
dream Renderer
author: forDream
*/

#pragma once
#include"Core/Geometry.h"

class GameObject
{
public:
	GameObject();
	vec3f GetPos() const;
	void SetPos(vec3f pos);
	vec3f GetRotation() const;
	void SetRotation(vec3f rotate);
	vec3f GetScale() const;
	void SetScale(vec3f scale);
private:
	vec3f pos;
	vec3f rotate;
	vec3f scale;
};
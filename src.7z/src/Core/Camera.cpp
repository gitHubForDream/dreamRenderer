/*
dream Renderer
author: forDream
*/

#include"Camera.h"

vec3f POS = vec3f(0.0, 0.0, 10.0);
vec3f TARGET = vec3f(0.0, 0.0, 0.0);

CCamera::CCamera() 
{
	this->SetPos(POS);
	this->front = FRONT;
	this->up = UP;
	this->yaw = 0.0f;
	this->pitch = 0.0f;
}

CCamera::CCamera(vec3f pos_, vec3f front_, vec3f up_): front(front_), up(up_) 
{
	this->SetPos(pos_);
	this->yaw = 0.0f;
	this->pitch = 0.0f;
}

void CCamera::LookAt(vec3f target)
{
	// TODO ��ʵ�ָ��ڵײ���ѧ����
	vec3f pos = this->GetPos();
	vec3f z_axis = normalize(pos - target);
	vec3f x_axis = normalize(cross(this->up, z_axis));
	vec3f y_axis = cross(z_axis, x_axis);


	mat4f translation = mat4f();
	translation.m[0][3] = -pos.x;
	translation.m[1][3] = -pos.y;
	translation.m[2][3] = -pos.z;

	mat4f rotation = mat4f();
	rotation.m[0][0] = x_axis.x;
	rotation.m[0][1] = x_axis.y;
	rotation.m[0][2] = x_axis.z;
	rotation.m[1][0] = y_axis.x;
	rotation.m[1][1] = y_axis.y;
	rotation.m[1][2] = y_axis.z;
	rotation.m[2][0] = z_axis.x;
	rotation.m[2][1] = z_axis.y;
	rotation.m[2][2] = z_axis.z;

	this->m_viewMatrix = rotation * translation;
}

mat4f CCamera::GetViewMatrix() 
{
	return this->m_viewMatrix;
}

mat4f CCamera::GetProjectionMatrix() 
{
	return mat4f();
}

void CCamera::Move(float xOffset, float yOffset)
{
	float sensitiviy = 0.05;
	xOffset *= sensitiviy;
	yOffset *= sensitiviy;

	yaw += xOffset;
	pitch += yOffset;

	pitch = (pitch > 90.0f) ? 90.0f : pitch;
	pitch = (pitch < -90.0f) ? -90.0f : pitch;

	front.x = cos(radians(yaw)) * cos(radians(pitch));
	front.y = sin(radians(pitch));
	front.z = sin(radians(yaw)) * cos(radians(pitch));
	front = normalize(front);
}
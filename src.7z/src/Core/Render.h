/*
dream Renderer
author: forDream
*/

#pragma once
#include"Framebuffer.h"
#include"Core/Geometry.cpp"

const int LEFT = -1000;
const int RIGHT = 1000;
const int TOP = 1000;
const int BOTTOM = -1000;
const int NEAR_ = 1000;
const int FAR_ = -1000;


mat4f GetViewportMatrix(float w, float h, float near_, float far_)
{
	mat4f viewport_matrix;
	viewport_matrix.m[0][0] = w / 2;
	viewport_matrix.m[0][3] = w / 2;
	viewport_matrix.m[1][1] = h / 2;
	viewport_matrix.m[1][3] = h / 2;
	viewport_matrix.m[2][2] = (far_ - near_) / 2;
	viewport_matrix.m[2][3] = (far_ + near_) / 2;
	return viewport_matrix;
}

mat4f GetProjectionMatrix1(float fovy, float aspect, float near_, float far_)
{
	mat4f viewport_matrix;
	fovy = fovy / 180 * 3.141592654;
	float t = fabs(near_) * tan(fovy / 2);
	float r = aspect * t;

	viewport_matrix.m[0][0] = near_ / r;
	viewport_matrix.m[1][1] = near_ / t;
	viewport_matrix.m[2][2] = -(near_ + far_) / (far_ - near_);
	viewport_matrix.m[2][3] = -2 * near_*far_ / (far_ - near_);
	viewport_matrix.m[3][2] = -1;
	viewport_matrix.m[3][3] = 0;
	return viewport_matrix;
}

mat4f GetProjectionMatrix(float left, float right, float top, float bottom, float near_, float far_)
{
	mat4f projectionMatrix;
	projectionMatrix.m[0][0] = (2 * near_) / (right - left);
	projectionMatrix.m[0][2] = (right + left) / (right - left);
	projectionMatrix.m[1][1] = (2 * near_) / (top - bottom);
	projectionMatrix.m[1][2] = (top + bottom) / (top - bottom);
	projectionMatrix.m[2][2] = -(near_ + far_) / (far_ - near_);
	projectionMatrix.m[2][3] = -(2 * near_ * far_) / (far_ - near_);
	projectionMatrix.m[3][2] = -1;
	projectionMatrix.m[3][3] = 0;
	return projectionMatrix;
}

mat4f GetProjectionMatrix2(float left, float right, float top, float bottom, float near_, float far_)
{
	mat4f projectionMatrix;
	projectionMatrix.m[0][0] = 2 / (right - left);
	projectionMatrix.m[0][3] = -(right + left) / (right - left);
	projectionMatrix.m[1][1] = 2 / (top - bottom);
	projectionMatrix.m[1][2] = -(top + bottom) / (top - bottom);
	projectionMatrix.m[2][2] = - 2 / (far_ - near_);
	projectionMatrix.m[2][3] = -(near_ + far_) / (far_ - near_);
	return projectionMatrix;
}

mat4f GetWorldMatrix(vec3f pos, vec3f scale)
{
	mat4f worldMatrix;
	worldMatrix.m[0][3] = pos.x;
	worldMatrix.m[1][3] = pos.y;
	worldMatrix.m[2][3] = pos.z;

	worldMatrix.m[0][0] = scale.x;
	worldMatrix.m[1][1] = scale.y;
	worldMatrix.m[2][2] = scale.z;
	return worldMatrix;
}

vec3i sampler2D(Texture texture, float u, float v)
{
	unsigned char* data = texture.data;
	int x = texture.width * u;
	int y = texture.height * v;
	int channels = texture.channels;
	vec3i rgb;
	int index = (x + y * texture.width) * channels;
	rgb[0] = data[index];
	rgb[1] = data[index + 1];
	rgb[2] = data[index + 2];
	return rgb;
}

void draw_point(int x, int y, FrameBuffer frame_buffer, int r, int g, int b)
{
	if (x > FRAME_BUFFER_WIDTH || y > FRAME_BUFFER_HEIGHT)
	{
		return;
	}
	frame_buffer.SetColor(x, y, r, g, b);
}

void draw_line(int x0, int y0, int x1, int y1, FrameBuffer frame_buffer, int r, int g, int b)
{
	if (x0 > FRAME_BUFFER_WIDTH || x1 > FRAME_BUFFER_WIDTH || y0 > FRAME_BUFFER_HEIGHT || y1 > FRAME_BUFFER_HEIGHT)
	{
		return;
	}
	bool steep = false;
	if (abs(x0 - x1) < abs(y0 - y1))
	{
		swap(x0, y0);
		swap(x1, y1);
		steep = true;
	}
	if (x0 > x1)
	{
		swap(x0, x1);
		swap(y0, y1);
	}
	int dx = x1 - x0;
	int dy = y1 - y0;
	float derror = abs(dy) * 2;
	float error = 0;
	int y = y0;
	for (int x = x0; x <= x1; x++)
	{
		if (steep)
		{
			frame_buffer.SetColor(y, x, r, g, b);
		}
		else
		{
			frame_buffer.SetColor(x, y, r, g, b);
		}
		error += derror;
		if (error > dx)
		{
			y += (y1 > y0 ? 1 : -1);
			error -= 2 * dx;
		}
	}
}

vec3f barycentric(vec3f v1, vec3f v2, vec3f v3, vec2i p)
{
	vec3f vx = vec3f(v3.x - v1.x, v2.x - v1.x, v1.x - p.x);
	vec3f vy = vec3f(v3.y - v1.y, v2.y - v1.y, v1.y - p.y);
	vec3f u = cross(vx, vy);
	if (abs(u[2]) < 1)
	{
		return vec3f(-1, 1, 1);
	}
	return vec3f(1 - (u.x + u.y) / u.z, u.y / u.z, u.x / u.z);
}

void draw_triangle(Texture& texture, vec3f *vertex, vec2f *uv, FrameBuffer frame_buffer)
{
	vec2i left_down(frame_buffer.Width() - 1, frame_buffer.Height() - 1);
	vec2i right_up(0, 0);
	vec2i buffer_size(frame_buffer.Width() - 1, frame_buffer.Height() - 1);
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 2; j++)
		{
			left_down[j] = max(0, min(left_down[j], vertex[i][j]));
			right_up[j] = min(buffer_size[j], max(right_up[j], vertex[i][j]));
		}
	}
	vec2i p;

	for (p.x = left_down.x; p.x <= right_up.x; p.x++)
	{
		for (p.y = left_down.y; p.y <= right_up.y; p.y++)
		{
			vec3f bary = barycentric(vertex[0], vertex[1], vertex[2], p);
			if (! (bary.x < 0 || bary.y < 0 || bary.z < 0))
			{
				vec2f inter_uv = vec2f(bary.x * uv[0].x, bary.x * uv[0].y) +
					vec2f(bary.y * uv[1].x, bary.y * uv[1].y) +
					vec2f(bary.z * uv[2].x, bary.z * uv[2].y);
				double depth = bary.x * vertex[0].z + bary.y * vertex[1].z + bary.z * vertex[2].z;
				bool depth_test = frame_buffer.DepthTest(p.x, p.y, depth);
				if (depth_test)
				{
					vec3i rgb = sampler2D(texture, inter_uv.x, inter_uv.y);
					frame_buffer.SetColor(p.x, p.y, rgb[0], rgb[1], rgb[2]);
				}
			}
		}
	}
}


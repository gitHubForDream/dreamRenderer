/*
dream Renderer
author: forDream
*/

//TODO ��geometry�ĳɺ��ʵ�����

#pragma once
#include<vector>
#include<iostream>

template <typename T>
class Vector2
{
public:
	Vector2();
	Vector2(T x_, T y_);
	Vector2(const Vector2<T> &v);
	Vector2<T>& operator=(const Vector2<T> &v);
	Vector2<T> operator+(const Vector2<T> &v);
	Vector2<T>& operator+=(const Vector2<T> &v);
	Vector2<T> operator-(const Vector2<T> &v);
	Vector2<T>& operator-=(const Vector2<T> &v);
	Vector2<T> operator*(const Vector2<T> &v);
	Vector2<T>& operator*=(const Vector2<T> &v);
	Vector2<T> operator/(const Vector2<T> &v);
	Vector2<T>& operator/=(const Vector2<T> &v);
	Vector2<T> operator-() const;
	T& operator[](int i);
	float Length() const;
	float LengthSquared() const;

	T x;				
	T y;
};


template <typename T>
class Vector3
{
public:
	Vector3();
	Vector3(T x_, T y_, T z_);
	Vector3(const Vector3<T> &v);
	Vector3<T>& operator=(const Vector3<T> &v);
	Vector3<T> operator+(T t);
	Vector3<T> operator+(const Vector3<T> &v);
	Vector3<T>& operator+=(const Vector3<T> &v);
	Vector3<T> operator-(const Vector3<T> &v);
	Vector3<T>& operator-=(const Vector3<T> &v);
	Vector3<T> operator*(T t);
	Vector3<T> operator*(const Vector3<T> &v);
	Vector3<T>& operator*=(const Vector3<T> &v);
	Vector3<T> operator/(T t);
	Vector3<T> operator/(const Vector3<T> &v);
	Vector3<T>& operator/=(T t);
	Vector3<T>& operator/=(const Vector3<T> &v);
	Vector3<T> operator-() const;
	T& operator[](int i);
	float Length() const;
	float LengthSquared() const;

	T x;
	T y;
	T z;
};

typedef Vector3<float> vec3f;

template <typename T, int n>
class Matrix
{
public:
	Matrix();
	Matrix(T m);
	Matrix(const T mat[n][n]);
	vec3f mult(const vec3f &v);
	vec3f mult1(const vec3f &v);
	Matrix<T, n> operator*(const Matrix<T, n> &m_);
	bool operator==(const Matrix<T, n> &m_) const;

	T m[4][4];
};

template <typename T>
inline T dot(const Vector3<T> &v1, const Vector3<T> &v2);

template <typename T>
inline Vector3<T> cross(const Vector3<T> &v1, const Vector3<T> &v2) 
{
	return vec3f(v1.y*v2.z - v1.z*v2.y, v1.z*v2.x - v1.x*v2.z, v1.x*v2.y - v1.y*v2.x);
}

typedef Vector3<int> vec3i;

typedef Vector2<int> vec2i;
typedef Vector2<float> vec2f;

typedef Matrix<int, 4> mat4i;
typedef Matrix<float, 4> mat4f;

template <typename T>
Vector3<T> normalize(Vector3<T> &v);

template <typename T>
T radians(T degree);
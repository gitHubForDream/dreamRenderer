/*
dream Renderer
author: forDream
*/

#define STB_IMAGE_IMPLEMENTATION
#include"Shape\Model.h"
#include"Gui\Win32.h"
#include"Core\Render.h"
#include"Core\Camera.h"

Win32 win32;
CCamera camera;
Model model("obj/nanosuit/nanosuit.obj");

int main(int argc, char *argv[])
{
	win32.InitWindow();
	FrameBuffer frame_buffer(FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT);
	
	//obj/gun/Handgun_obj.obj
	//obj/nanosuit/nanosuit.obj
	//obj/BumbleBee/Bumble.obj
	//obj/dragon/dragon.3ds
	while (true)
	{
		unsigned long begin_time = GetTickCount();
		win32.MessageLoop();
		frame_buffer.ClearFrameBuffer();
		vec3f cameraPos = camera.GetPos();
		vec3f lookAt = cameraPos - camera.front;
		camera.LookAt(lookAt);
		mat4f view_matrix = camera.GetViewMatrix();

		Vertex vertex;
		vec3f *vert = new vec3f[3];
		vec2f *uv = new vec2f[3];
		vec3f pos = model.GetPos();
		vec3f scale = model.GetScale();
		mat4f world_matrix = GetWorldMatrix(pos, scale);
		mat4f projection_matrix = GetProjectionMatrix(LEFT, RIGHT, TOP, BOTTOM, NEAR_, FAR_);
		projection_matrix = GetProjectionMatrix1(60, float(1024) / 768, NEAR_, FAR_);
		mat4f viewport_matrix = GetViewportMatrix(1.024 * 1000, 0.768 * 1000, NEAR_, FAR_);
		mat4f MVPMatrix = projection_matrix * view_matrix * world_matrix;
		for (size_t i = 0; i < model.meshes.size(); i++)
		{	
			Mesh mesh = model.meshes[i];
			Texture texture;
			if (mesh.textures.size() > 0)
			{
				texture = mesh.textures[0];
			}
			for (size_t j = 0; j < mesh.indices.size(); j += 3)
			{
				for (size_t k = j; k < j + 3; k++)
				{
					if (k > mesh.indices.size() - 1)
					{
						break;
					}
					int index = mesh.indices[k];
					//view trans
					vert[k - j] = MVPMatrix.mult(mesh.vertices[index].position);
				    vert[k - j] = viewport_matrix.mult(vert[k - j]);
					uv[k - j] = vec2f(mesh.vertices[index].texcoords.x, mesh.vertices[index].texcoords.y);
				}
				draw_triangle(texture, vert, uv, frame_buffer);
			}
		}
		//for (int i = 0; i < model.meshes.size(); i++)	
		//{
		//	Mesh mesh = model.meshes[i];
		//	for (int j = 0; j < mesh.indices.size(); j += 3)
		//	{
		//		for (size_t k = j; k < j + 3; k++)
		//		{
		//			if (k > mesh.indices.size() - 1)
		//			{
		//				break;
		//			}
		//			int index = mesh.indices[k];
		//			vert[k - j] = MVPMatrix.mult(mesh.vertices[index].position);
		//			vert[k - j] = viewport_matrix.mult(vert[k - j]);
		//		}
		//		draw_line(vert[0].x, vert[0].y, vert[1].x, vert[1].y, frame_buffer, 0, 0, 255);
		//		draw_line(vert[1].x, vert[1].y, vert[2].x, vert[2].y, frame_buffer, 0, 0, 255);
		//		draw_line(vert[2].x, vert[2].y, vert[0].x, vert[0].y, frame_buffer, 0, 0, 255);
		//	}
		//}
		//for (int i = 0; i < model.meshes.size(); i++)
		//{
		//	Mesh mesh = model.meshes[i];
		//	for (int j = 0; j < mesh.indices.size(); j++)
		//	{
		//		vec3f vert;
		//		int index = mesh.indices[j];
		//		vert = MVPMatrix.mult(mesh.vertices[index].position);
		//		vert = viewport_matrix.mult(vert);
		//		draw_point(vert.x, vert.y, frame_buffer, 255, 255, 255);
		//	}
		//}
		unsigned long end_time = GetTickCount();
		win32.Draw(frame_buffer, 1.0 / ((end_time - begin_time) / 1000.0));
		// cout << 1.0 / ((end_time - begin_time) / 1000.0) << endl;
	}
	system("pause");
	return 0;
}
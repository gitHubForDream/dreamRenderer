/*
dream Renderer
author: forDream
*/

#include"Win32.h"
#include"Core/Camera.h"
#include"Shape/Model.h"
#include<iostream>

Win32::Win32()
{
	this->frame_buffer = FrameBuffer(FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT);
}

void Win32::InitWindow()
{
	this->RegisterWindow();

	bool is_inited;
	is_inited = this->InitInstance();
	if (!is_inited)
	{
		return;
	}

	this->InitGraph();
}

void Win32::RegisterWindow()
{
	WNDCLASS wcex;

	wcex.style = CS_BYTEALIGNCLIENT;
	wcex.lpfnWndProc = (WNDPROC)WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = GetModuleHandle(NULL);
	wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
	wcex.lpszMenuName = NULL;
	wcex.lpszClassName = this->class_name;

	ATOM atom = RegisterClass(&wcex);
}

bool Win32::InitInstance()
{
	HWND hWnd = CreateWindow(this->class_name, this->title_name, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, 0, 1024, 768, NULL, NULL, GetModuleHandle(NULL), NULL);

	if (!hWnd)
	{
		return false;
	}

	this->hWnd = hWnd;
	ShowWindow(hWnd, SW_SHOWNORMAL);
	return true;
}

HWND Win32::GetHWnd()
{
	return this->hWnd;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_MOUSEWHEEL:
	{
		short delta = HIWORD(wParam);
		vec3f model_scale = model.GetScale();
		vec3f camera_pos = camera.GetPos();
		if (delta > 0)
		{
			//model.SetScale(model_scale * 1.1);
			camera.SetPos(vec3f(camera_pos.x, camera_pos.y, camera_pos.z + 1));
		}
		else
		{
			//model.SetScale(model_scale * 0.9);
			camera.SetPos(vec3f(camera_pos.x, camera_pos.y, camera_pos.z - 1));
		}
		break;
	}
	case WM_LBUTTONDOWN:
	{
		win32.isLButtonPressed = true;
		cout << "l button down" << endl;
		break;
	}
	case WM_LBUTTONUP:
	{
		win32.isLButtonPressed = false;
		win32.isFirstMove = true;
		cout << "l button up" << endl;
		break;
	}
	case WM_MOUSEMOVE:
	{
		if (!win32.isLButtonPressed)
		{
			break;
		}
		POINT cursor;
		GetCursorPos(&cursor);
		ScreenToClient(win32.GetHWnd(), &cursor);
		int xPos = cursor.x;
		int yPos = cursor.y;
		if (win32.isFirstMove)
		{
			win32.curPosX = xPos;
			win32.curPosX = yPos;
			win32.isFirstMove = false;
			break;
		}
		int xOffset = xPos - win32.curPosX;
		int yOffset = yPos - win32.curPosY;

		win32.curPosX = xPos;
		win32.curPosY = yPos;

		camera.Move(xOffset, yOffset);
		cout << "mouse move" << xPos << " " << yPos << endl;
		break;
	}
	case WM_RBUTTONDOWN:
	{
		cout << "r button down" << endl;
		break;
	}
	case WM_RBUTTONUP:
	{
		cout << "r button up" << endl;
		break;
	}
	case WM_KEYDOWN:
	{
		vec3f camera_pos = camera.GetPos();
		vec3f model_pos = model.GetPos();
		if (wParam == VK_LEFT)
		{
			camera.SetPos(vec3f(camera_pos.x + 1, camera_pos.y, camera_pos.z));
		}
		if (wParam == VK_RIGHT)
		{
			camera.SetPos(vec3f(camera_pos.x - 1, camera_pos.y, camera_pos.z));
		}
		if (wParam == VK_UP)
		{
			camera.SetPos(vec3f(camera_pos.x, camera_pos.y + 1, camera_pos.z));
		}
		if (wParam == VK_DOWN)
		{
			camera.SetPos(vec3f(camera_pos.x, camera_pos.y - 1, camera_pos.z));
		}
		if (wParam == 65)
		{
			model.SetPos(vec3f(model_pos.x - 1, model_pos.y, model_pos.z));
		}
		if (wParam == 65 + ('d' - 'a'))
		{
			model.SetPos(vec3f(model_pos.x + 1, model_pos.y, model_pos.z));
		}
		if (wParam == 65 + ('w' - 'a'))
		{
			model.SetPos(vec3f(model_pos.x, model_pos.y + 1, model_pos.z));
		}
		if (wParam == 65 + ('s' - 'a'))
		{
			model.SetPos(vec3f(model_pos.x, model_pos.y - 1, model_pos.z));
		}
		break;
	}
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}

	return 0;
}

void Win32::MessageLoop()
{
	MSG msg;
	while (true)
	{
		if (!PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE))
		{
			break;
		}
		if (!GetMessage(&msg, NULL, 0, 0))
		{
			break;
		}
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

void Win32::InitGraph()
{
	BITMAPINFOHEADER bitmap_info;
	this->InitBitMap(bitmap_info);

	HDC hdc = GetDC(this->hWnd);
	HDC compatible_hdc = CreateCompatibleDC(hdc);
	this->compatible_hdc = compatible_hdc;
	ReleaseDC(this->hWnd, hdc);

	LPVOID void_ptr;
	HBITMAP hbitmap = CreateDIBSection(compatible_hdc, (BITMAPINFO*)&bitmap_info, DIB_RGB_COLORS, &void_ptr, 0, 0);
	if (hbitmap == NULL)
	{
		return;
	}

	SelectObject(compatible_hdc, hbitmap);
	this->frame_buffer.SetFrameBuffer((char*)void_ptr);

	memset(this->frame_buffer.GetFrameBuffer(), 0, FRAME_BUFFER_WIDTH * FRAME_BUFFER_HEIGHT * 4);
}

void Win32::InitBitMap(BITMAPINFOHEADER &bitmap_info)
{
	memset(&bitmap_info, 0, sizeof(BITMAPINFOHEADER));
	bitmap_info.biSize = sizeof(BITMAPINFOHEADER);
	bitmap_info.biWidth = FRAME_BUFFER_WIDTH;
	bitmap_info.biHeight = FRAME_BUFFER_HEIGHT;
	bitmap_info.biPlanes = 1;
	bitmap_info.biBitCount = 32;
	bitmap_info.biCompression = BI_RGB;
	bitmap_info.biSizeImage = FRAME_BUFFER_WIDTH * FRAME_BUFFER_HEIGHT * 4;
}

void Win32::Draw(FrameBuffer frame_buffer_, double dFps)
{
	char* buffer = this->frame_buffer.GetFrameBuffer();
	char* buffer_ = frame_buffer_.GetFrameBuffer();

	//TODO �ĳ�memcpy
	int height = frame_buffer_.Height();
	int width = frame_buffer_.Width();
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			int index = (j * width + i) * 4;
			int r = buffer_[index];
			int g = buffer_[index + 1];
			int b = buffer_[index + 2];
			buffer[index] = buffer_[index];
			buffer[index + 1] = buffer_[index + 1];
			buffer[index + 2] = buffer_[index + 2];
		}
	}
	
	HDC hdc = GetDC(this->hWnd);
	BitBlt(hdc, 0, 0, FRAME_BUFFER_WIDTH, FRAME_BUFFER_HEIGHT, this->compatible_hdc, 0, 0, SRCCOPY);
	
	char cFps[16];

	sprintf_s(cFps, "%d", int(dFps));
	string sFps = cFps;
	std::cout << sFps << std::endl;
	TextOut(hdc, 0, 0, (LPCWSTR)sFps.c_str(), sFps.length());
	ReleaseDC(this->hWnd, hdc);
}

/*
dream Renderer
author: forDream
*/

#pragma once
#include"Core\Framebuffer.h"
#include<Windows.h>

static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

class Win32
{
public:
	Win32();
	void InitWindow();
	void Draw(FrameBuffer frame_buffer, double dFps);
	void MessageLoop();
	HWND GetHWnd();
	bool isFirstMove = false;
	int curPosX = 0;
	int curPosY = 0;
	bool isLButtonPressed = false;
	bool isRButtonPressed = false;

private:
	void RegisterWindow();
	bool InitInstance();
	void InitGraph();
	void InitBitMap(BITMAPINFOHEADER &bitmap_info);

	const wchar_t* class_name = L"dream Renderer";
	const wchar_t* title_name = L"dream Renderer";

	FrameBuffer frame_buffer;
	HWND hWnd;
	HDC compatible_hdc;
};

extern Win32 win32;